import { useSiteSettings, useEffectiveDataMode, Unavailable } from "./lib/siteSettings";
import { Suspense, lazy, useEffect, useState } from "react";
import type { AgeId, SaveData, DailyChallengeAttempt } from "./lib/storage";
import { clearSave, defaultSave, loadSave, loadSaveFor, persist, rankOf, recordDailyStreak, isDailyCompletedToday, getLocalDateString } from "./lib/storage";
import { AGE_GROUPS, getModule } from "./data/modules";
import { getSession, questId } from "./data/quests";
import type { Session } from "./data/quests";
import { getDailyChallenge } from "./data/dailyChallenges";
import { applyAttempt, meetingLevel, meetingUnlocked } from "./lib/progress";
import { logAttempt } from "./lib/history";
import { enqueueAttempt, pushOutbox } from "./lib/sync";
import { guestUser, rememberUserId, signInWithGoogle, type AuthUser } from "./lib/auth";
import { isCloudReady } from "./lib/supabaseClient";
import Pertemuan from "./ui/Pertemuan";
import { sfx } from "./lib/audio";
import Ambient from "./graphics/Ambient";
import Onboarding from "./ui/Onboarding";
import Dashboard from "./ui/Dashboard";
import CrossPlatformHud from "./ui/CrossPlatformHud";
import Materi from "./ui/Materi";
import MateriHtml from "./ui/MateriHtml";
import type { GameResult } from "./ui/TypingGame";
import { isTouchDevice } from "./lib/device";
import { SUBGAMES, loadSubGame, saveSubGame } from "./data/subgames";
import type { SubGameId } from "./data/subgames";
import Results from "./ui/Results";

import {
  getPermanentStreakTier,
  applyStreakMultiplier,
  recordDailyLoginStreak,
  checkStreakMilestoneUnlocked,
} from "./lib/streakMultiplier";

/* Heavy arena di-lazy agar hub & first-paint HP tetap cepat (code-split per sub-game). */
const TypingGame = lazy(() => import("./ui/TypingGame"));
const TowerPuzzle = lazy(() => import("./ui/TowerPuzzle"));
const CrossPlatformLab = lazy(() => import("./games/crossplatform/CrossPlatformLab"));

interface AppProps {
  /** bila diisi, entry ini dikunci ke satu sub-game (dipakai entry /codingshark & /codingtower).
      null/undefined = mode agregat lama (bisa ganti arena, dipakai dev & fallback). */
  lockedSubGame?: SubGameId | null;
  /** tampilkan tautan kembali ke hub agregat latihan.my.id */
  hubHref?: string;
  /** tautan ke arena saudara (mis. dari shark → tower) */
  siblingHref?: string;
  siblingLabel?: string;
}

type Screen =
  | { s: "dash" }
  | { s: "peta"; no: number }
  | { s: "materi"; id: string }
  | { s: "materi-html"; no?: number }
  | { s: "game"; id: string; k: number }
  | {
      s: "result";
      id: string;
      r: GameResult;
      xp: number;
      coins: number;
      rankUp: string | null;
      passed: boolean;
      streakCount?: number;
      isDaily?: boolean;
      dailyBonusXp?: number;
      dailyBonusCoins?: number;
      streakMultiplier?: number;
      streakTierName?: string;
      streakBonusXp?: number;
      streakBonusCoins?: number;
      newStreakTierUnlocked?: {
        tier: number;
        name: string;
        multiplier: number;
      } | null;
    };

export default function App({ lockedSubGame = null, hubHref, siblingHref, siblingLabel }: AppProps) {
  const settings = useSiteSettings();
  const dataMode = useEffectiveDataMode();
  const [save, setSave] = useState<SaveData>(() => loadSave());
  const [sound, setSound] = useState<boolean>(() => loadSave().profile?.sound ?? true);
  const [screen, setScreen] = useState<Screen>({ s: "dash" });
  const [gameKey, setGameKey] = useState(0);
  /* SUB-GAME aktif — dipilih di hub Dashboard, tersimpan antar sesi.
     Bila entry dikunci (/codingshark, /codingtower) pilihan dikunci juga. */
  const [touch] = useState(() => isTouchDevice());
  const [subGame, setSubGame] = useState<SubGameId>(() => {
    if (lockedSubGame) return lockedSubGame;
    try {
      const params = new URLSearchParams(window.location.search);
      const sg = params.get("subgame");
      if (
        sg === "crossplatform" ||
        sg === "tower" ||
        sg === "shark"
      ) {
        return sg;
      }
    } catch {
      /* abaikan */
    }
    return loadSubGame(isTouchDevice() ? "tower" : "shark");
  });

  const selectSubGame = (id: SubGameId) => {
    if (lockedSubGame) return;
    setSubGame(id);
    saveSubGame(id);
  };

  useEffect(() => persist(save), [save]);
  // Sinkron cloud hanya bila mode EFEKTIF cloud (tes koneksi awal ke
  // TiDB Cloud/Aiven berhasil). persist() ke localStorage di atas selalu
  // jalan (local-first). Mode dibaca via hook agar re-tes berkala yang
  // menaikkan mode ke cloud langsung mengaktifkan effect ini.
  // Sync only after React has committed the latest snapshot, not the pre-run save.
  useEffect(() => {
    if (dataMode.mode !== "cloud") return;
    const sync = () => { pushOutbox(save.deviceId, save.profile?.name ?? null, save).catch(() => {}); };
    const timer = window.setTimeout(sync, 300);
    window.addEventListener("online", sync);
    return () => {
      window.clearTimeout(timer);
      window.removeEventListener("online", sync);
    };
  }, [save, dataMode.mode]);
  useEffect(() => {
    sfx.enabled = sound;
  }, [sound]);

  // Cek login harian saat aplikasi dibuka dan evaluasi streak login serta multiplier permanen
  useEffect(() => {
    if (!save.profile) return;
    const { nextSave } = recordDailyLoginStreak(save);
    if (
      nextSave.loginStreak?.current !== save.loginStreak?.current ||
      nextSave.loginStreak?.lastActiveDate !== save.loginStreak?.lastActiveDate ||
      (nextSave.unlockedStreakMilestones?.length ?? 0) !== (save.unlockedStreakMilestones?.length ?? 0)
    ) {
      setSave(nextSave);
    }
  }, []);

  const profile = save.profile;
  const cfg = AGE_GROUPS[profile?.age ?? "teen"];

  /* ===== aksi profil ===== */
  const adoptAccountSave = (account: AuthUser) => {
    if (account.provider !== "email" || account.banned) return;
    rememberUserId(account.id);
    // Bila akun ini sudah punya save lokal di perangkat yang sama, pakai
    // namespace akunnya (jangan timpa dengan save tamu kosong).
    setSave((current) => (current.profile ? current : loadSaveFor(account.id)));
  };

  const createProfile = (name: string, age: AgeId, account?: AuthUser | null) => {
    sfx.click();
    if (account?.provider === "email" && !account.banned) rememberUserId(account.id);
    else guestUser(name);
    setSave((s) => ({
      ...s,
      profile: { name, age, sound, createdAt: Date.now() },
    }));
    setScreen({ s: "dash" });
  };

  const toggleSound = () => {
    const next = !sound;
    setSound(next);
    setSave((s) => (s.profile ? { ...s, profile: { ...s.profile, sound: next } } : s));
  };

  const resetProfile = () => {
    clearSave();
    setSave(defaultSave());
    setScreen({ s: "dash" });
    sfx.click();
  };

  /* ===== aksi permainan ===== */
  const completeMateri = (id: string, quizXp: number) => {
    const prev = save.modules[id] ?? { materiDone: false, quizXp: 0, completions: 0 };
    const firstRead = !prev.materiDone;
    const firstQuiz = prev.quizXp === 0 && quizXp > 0;
    const baseGained = (firstRead ? 20 : 0) + (firstQuiz ? quizXp : 0);
    const { nextStreak } = recordDailyStreak(save.streak);
    const highestStreak = Math.max(
      nextStreak.current,
      nextStreak.best,
      save.loginStreak?.current ?? 0,
      save.loginStreak?.best ?? 0
    );
    const { nextSave: saveWithMilestone } = checkStreakMilestoneUnlocked(save, highestStreak);
    const multiplierTier = getPermanentStreakTier(saveWithMilestone);
    const gained = Math.round(baseGained * multiplierTier.multiplier);

    setSave((s) => {
      const p = s.modules[id] ?? { materiDone: false, quizXp: 0, completions: 0 };
      return {
        ...s,
        xp: s.xp + gained,
        streak: nextStreak,
        unlockedStreakMilestones: saveWithMilestone.unlockedStreakMilestones,
        unlockedStreakTiers: saveWithMilestone.unlockedStreakTiers,
        modules: {
          ...s.modules,
          [id]: { ...p, materiDone: true, quizXp: Math.max(p.quizXp, quizXp) },
        },
      };
    });
    /* pertama kali selesai materi → langsung lanjut ke praktikum (alur belajar) */
    if (firstRead) enterPractice(id);
    else setScreen({ s: "dash" });
  };

  const enterPractice = (id: string) => {
    setGameKey((k) => k + 1);
    setScreen({ s: "game", id, k: gameKey + 1 });
  };

  /* sesi dihitung ulang di sini (satu sumber aturan: lib/progress.ts).
     XP & koin hanya bertambah di atas hasil terbaik sesi → replay tanpa peningkatan tidak menambah XP. */
  const finishPractice = (id: string, r: GameResult) => {
    const sess = getSession(id) ?? getSession("q:1:quest") ?? (getSession("html") as Session);
    if (!sess) return setScreen({ s: "dash" });

    const isDaily = id.startsWith("daily:");
    const alreadyDoneToday = isDaily && isDailyCompletedToday(save);
    const daily = isDaily ? getDailyChallenge() : null;
    const dailyBonusXp = isDaily && r.won && !alreadyDoneToday ? (daily?.bonusXp ?? 150) : 0;
    const dailyBonusCoins = isDaily && r.won && !alreadyDoneToday ? (daily?.bonusCoins ?? 35) : 0;

    const xpSession = r.won ? 50 + r.stars * 25 + Math.round(r.accuracy / 5) : Math.round(r.score / 25);
    const coinsSession = r.won ? 10 + r.stars * 10 + Math.round(r.accuracy / 10) : 0;
    const { next, passed, xpAward, coinsAward } = applyAttempt(save.modules[id], sess, r, xpSession, coinsSession);

    // Hitung streak baru
    const { nextStreak } = recordDailyStreak(save.streak);
    const highestStreak = Math.max(
      nextStreak.current,
      nextStreak.best,
      save.loginStreak?.current ?? 0,
      save.loginStreak?.best ?? 0
    );

    // Evaluasi apakah ada tier Streak Multiplier baru yang terbuka secara permanen!
    const { nextSave: saveWithMilestone, newlyUnlockedTier } = checkStreakMilestoneUnlocked(save, highestStreak);
    const multiplierTier = getPermanentStreakTier(saveWithMilestone);

    // Terapkan Streak Multiplier permanen ke seluruh hadiah misi!
    const baseTotalXp = xpAward + dailyBonusXp;
    const baseTotalCoins = coinsAward + dailyBonusCoins;
    const multiplied = applyStreakMultiplier(baseTotalXp, baseTotalCoins, multiplierTier);

    const totalXpAward = multiplied.totalXp;
    const totalCoinsAward = multiplied.totalCoins;
    const streakBonusXp = multiplied.bonusXp;
    const streakBonusCoins = multiplied.bonusCoins;

    const prevRankName = rankOf(save.xp).cur.name;
    const newRankName = rankOf(save.xp + totalXpAward).cur.name;
    const rankUp = newRankName !== prevRankName ? newRankName : null;

    const rec = logAttempt({
      sessionId: id, won: r.won, stars: r.stars, score: r.score,
      accuracy: r.accuracy, wpm: r.wpm, maxCombo: r.maxCombo,
      xpAward: totalXpAward, coinsAward: totalCoinsAward, passed,
    });
    enqueueAttempt(rec);

    const linesAwarded = r.linesCompleted ?? (r.won ? Math.max(1, Math.round(r.correct / 20)) : 0);

    setSave((s) => ({
      ...s,
      xp: s.xp + totalXpAward,
      coins: s.coins + totalCoinsAward,
      streak: nextStreak,
      unlockedStreakMilestones: saveWithMilestone.unlockedStreakMilestones,
      unlockedStreakTiers: saveWithMilestone.unlockedStreakTiers,
      dailyChallenge: isDaily && r.won ? (() => {
        const todayStr = getLocalDateString();
        const curChallenge = getDailyChallenge();
        const prevHist = s.dailyChallenge?.history ?? [];
        const newAttempt: DailyChallengeAttempt = {
          date: todayStr,
          title: curChallenge.title,
          lang: curChallenge.lang,
          score: r.score,
          accuracy: r.accuracy,
          wpm: r.wpm,
          stars: r.stars,
          timeSec: r.timeSec,
          completedAt: Date.now(),
        };
        const filteredHist = prevHist.filter((h) => h.date !== todayStr);
        return {
          lastCompletedDate: todayStr,
          todayScore: Math.max(s.dailyChallenge?.todayScore ?? 0, r.score),
          todayAccuracy: Math.max(s.dailyChallenge?.todayAccuracy ?? 0, r.accuracy),
          totalCompleted: (s.dailyChallenge?.totalCompleted ?? 0) + (alreadyDoneToday ? 0 : 1),
          history: [newAttempt, ...filteredHist],
        };
      })() : s.dailyChallenge,
      modules: { ...s.modules, [id]: next },
      stats: {
        games: s.stats.games + 1,
        wins: s.stats.wins + (r.won ? 1 : 0),
        bestWpm: Math.max(s.stats.bestWpm, r.won ? r.wpm : 0),
        bestCombo: Math.max(s.stats.bestCombo, r.maxCombo),
        keystrokes: s.stats.keystrokes + r.correct + r.errors,
        correct: s.stats.correct + r.correct,
        linesTyped: (s.stats.linesTyped ?? Math.max(0, Math.floor((s.stats.correct || 0) / 18))) + linesAwarded,
      },
    }));
    setScreen({
      s: "result", id, r,
      xp: totalXpAward,
      coins: totalCoinsAward,
      rankUp, passed,
      streakCount: nextStreak.current,
      isDaily,
      dailyBonusXp,
      dailyBonusCoins,
      streakMultiplier: multiplierTier.multiplier,
      streakTierName: multiplierTier.name,
      streakBonusXp,
      streakBonusCoins,
      newStreakTierUnlocked: newlyUnlockedTier ? {
        tier: newlyUnlockedTier.tier,
        name: newlyUnlockedTier.name,
        multiplier: newlyUnlockedTier.multiplier,
      } : null,
    });
  };

  const claimAchievement = (badgeId: string, rewardXp: number, rewardCoins: number) => {
    sfx.badge();
    setSave((s) => {
      const prevClaimed = s.claimedAchievements ?? {};
      if (prevClaimed[badgeId]) return s;
      return {
        ...s,
        xp: s.xp + rewardXp,
        coins: s.coins + rewardCoins,
        claimedAchievements: {
          ...prevClaimed,
          [badgeId]: Date.now(),
        },
      };
    });
  };

  /* pertemuan dibuka dari peta / materi HTML → sesi pertemuan itu */
  const playQuest = (no: number, kind: "quest" | "drill" | "juggle") => enterPractice(questId(no, kind));

  /* ===== Runtime gates also protect direct entry URLs and restored screens. ===== */
  if (!settings.games[subGame]) return <Unavailable message="Sub-game ini dinonaktifkan sementara." />;
  const selectedModule = screen.s === "materi" ? getModule(screen.id).lang
    : screen.s === "game" ? getSession(screen.id)?.lang
    : screen.s === "materi-html" ? "html" : null;
  if ((subGame === "tower" || subGame === "shark") && selectedModule && !settings.modules[selectedModule]) {
    return <Unavailable message="Modul ini dinonaktifkan sementara." retry={() => setScreen({ s: "dash" })} />;
  }

  /* ===== render ===== */
  return (
    <div className={`age-${cfg.id}`} style={{ "--accent": cfg.accent, "--accent-deep": shade(cfg.accent) } as React.CSSProperties}>
      <Ambient fish={subGame !== "crossplatform" && (!profile || screen.s === "dash")} />

      {!profile ? (
        <Onboarding
          soundOn={sound}
          onToggleSound={toggleSound}
          onCreate={createProfile}
          cloudReady={isCloudReady()}
          onGoogleLogin={() => signInWithGoogle().catch(() => {})}
          onAccountLogin={adoptAccountSave}
        />
      ) : screen.s === "dash" ? (
        subGame === "crossplatform" ? (
          <CrossPlatformHud
            save={save}
            onOpenMeeting={(no) => enterPractice(`crossplatform:${no}`)}
            onOpenLab={() => enterPractice("crossplatform:1")}
            onToggleSound={toggleSound}
            onResetProfile={resetProfile}
            subGame={subGame}
            onSelectSubGame={lockedSubGame ? undefined : selectSubGame}
            hubHref={hubHref}
            siblingHref={siblingHref}
            siblingLabel={siblingLabel}
            lockedSubGame={lockedSubGame}
          />
        ) : (
          <>
            {lockedSubGame && (hubHref || siblingHref) && (
              <div className="relative z-40 max-w-6xl mx-auto px-4 pt-3 flex items-center gap-2 text-[12px] font-bold">
                {hubHref && (
                  <a href={hubHref} className="chip hover:brightness-125">
                    ⌂ Hub latihan.my.id
                  </a>
                )}
                <span className="chip !text-[var(--teal)]">
                  {lockedSubGame === "crossplatform"
                    ? "📱 CrossPlatform Studio"
                    : lockedSubGame === "tower"
                    ? "🧱 Coding Tower"
                    : "🦈 CodeShark"}{" "}
                  • mode sub-game mandiri
                </span>
                {siblingHref && (
                  <a href={siblingHref} className="chip hover:brightness-125 ml-auto">
                    {siblingLabel ?? "Arena lain →"}
                  </a>
                )}
              </div>
            )}
            <Dashboard
              save={save}
              cfg={cfg}
              onMateri={(id) =>
                /* modul HTML memakai dokumen .md per pertemuan sebagai materi utama */
                id === "html" ? setScreen({ s: "materi-html" }) : setScreen({ s: "materi", id })
              }
              onPractice={enterPractice}
              onDailyChallenge={enterPractice}
              onClaimAchievement={claimAchievement}
              onMateriHtml={() => setScreen({ s: "materi-html" })}
              onPeta={() => setScreen({ s: "peta", no: nextMeeting(save) })}
              subGame={subGame}
              isTouch={touch}
              onSelectSubGame={lockedSubGame ? undefined : selectSubGame}
              onToggleSound={toggleSound}
              onResetProfile={resetProfile}
            />
          </>
        )
      ) : screen.s === "peta" ? (
        <Pertemuan
          key={screen.no}
          save={save}
          startNo={screen.no}
          subGame={subGame}
          onExit={() => setScreen({ s: "dash" })}
          onMateri={(no) => setScreen({ s: "materi-html", no })}
          onPlay={(no, kind) => playQuest(no, kind)}
        />
      ) : screen.s === "materi-html" ? (
        <MateriHtml
          startNo={screen.no}
          save={save}
          onPractice={enterPractice}
          onExit={() => setScreen({ s: "dash" })}
        />
      ) : screen.s === "materi" ? (
        <Materi
          key={screen.id}
          mod={getModule(screen.id)}
          cfg={cfg}
          alreadyDone={!!save.modules[screen.id]?.materiDone}
          onComplete={(quizXp) => completeMateri(screen.id, quizXp)}
          onPractice={() => enterPractice(screen.id)}
          onExit={() => setScreen({ s: "dash" })}
        />
      ) : screen.s === "game" ? (
        <div key={`${screen.id}-${screen.k}`}>
          {/* banner arena aktif — ganti sub-game tanpa kembali ke hub */}
          <div className="relative z-40 max-w-5xl mx-auto px-4 pt-3">
            {lockedSubGame ? (
              <div className="mode-switch" role="note" aria-label="Sub-game aktif (dikunci)">
                <span className="mode-btn on" aria-current="true">
                  {lockedSubGame === "crossplatform"
                    ? "📱 CrossPlatform Studio"
                    : lockedSubGame === "tower"
                    ? "🧱 Coding Tower"
                    : "🦈 CodeShark"}
                </span>
                {siblingHref && (
                  <a className="mode-btn" href={siblingHref}>
                    {siblingLabel ?? "Coba arena lain →"}
                  </a>
                )}
                {hubHref && (
                  <a className="mode-btn" href={hubHref}>
                    ⌂ Hub latihan.my.id
                  </a>
                )}
              </div>
            ) : (
              <div className="mode-switch" role="tablist" aria-label="Sub-game aktif">
                {(["crossplatform", "tower", "shark"] as SubGameId[]).filter(id => settings.games[id]).map((id) => (
                  <button
                    key={id}
                    role="tab"
                    aria-selected={subGame === id}
                    className={`mode-btn ${subGame === id ? "on" : ""}`}
                    onClick={() => { selectSubGame(id); setGameKey((k) => k + 1); sfx.click(); }}
                  >
                    {id === "crossplatform"
                      ? "📱 CrossPlatform"
                      : id === "tower"
                      ? "🧱 Coding Tower"
                      : "🦈 CodeShark"}
                  </button>
                ))}
              </div>
            )}
            <p className="text-center text-[11px] text-[var(--faint)] font-semibold mt-1.5">
              Arena: <strong className="text-[var(--teal)]">{SUBGAMES[subGame].name}</strong> — {SUBGAMES[subGame].tagline}
              {touch && subGame === "shark" && " • keyboard HP menyulitkan simbol < > {} ;"}
            </p>
          </div>
          <Suspense fallback={<div className="max-w-5xl mx-auto px-4 py-16 text-center text-sm text-[var(--dim)] font-bold">Memuat arena…</div>}>
          {subGame === "crossplatform" ? (
            <CrossPlatformLab
              key={`crossplatform-${screen.id}-${screen.k}-${gameKey}`}
              startMeetingNo={(() => {
                const m = /^crossplatform:(\d+)/.exec(screen.id)?.[1];
                return m ? parseInt(m, 10) : 1;
              })()}
              onDone={(r) => finishPractice(screen.id, r)}
              onExit={() => setScreen({ s: "dash" })}
            />
          ) : subGame === "tower" ? (
            <TowerPuzzle
              key={`susun-${screen.id}-${screen.k}-${gameKey}`}
              mod={sessionOf(screen.id)}
              cfg={cfg}
              onDone={(r) => finishPractice(screen.id, r)}
              onExit={() => setScreen({ s: "dash" })}
            />
          ) : (
            <TypingGame
              key={`ketik-${screen.id}-${screen.k}-${gameKey}`}
              mod={sessionOf(screen.id)}
              cfg={cfg}
              onDone={(r) => finishPractice(screen.id, r)}
              onExit={() => setScreen({ s: "dash" })}
            />
          )}
          </Suspense>
        </div>
      ) : (
        <Results
          mod={sessionOf(screen.id)}
          cfg={cfg}
          result={screen.r}
          passed={screen.passed}
          xpGained={screen.xp}
          coinsGained={screen.coins}
          rankUp={screen.rankUp}
          streakCount={screen.streakCount}
          isDaily={screen.isDaily}
          dailyBonusXp={screen.dailyBonusXp}
          dailyBonusCoins={screen.dailyBonusCoins}
          streakMultiplier={screen.streakMultiplier}
          streakTierName={screen.streakTierName}
          streakBonusXp={screen.streakBonusXp}
          streakBonusCoins={screen.streakBonusCoins}
          newStreakTierUnlocked={screen.newStreakTierUnlocked}
          onRetry={() => enterPractice(screen.id)}
          onMap={() => setScreen(meetingScreenOf(screen.id))}
        />
      )}
    </div>
  );
}

/* sesi aktif — id bisa berupa modul lama (html/css/js) atau sesi pertemuan (q:<no>:<kind>) */
function sessionOf(id: string): Session {
  return getSession(id) ?? (getSession("html") as Session);
}

/** kembali ke halaman peta bila sesi berasal dari pertemuan (q:<no>:<kind>), selain itu ke dashboard */
function meetingScreenOf(id: string): Screen {
  const m = /^q:(\d+):/.exec(id);
  if (m) return { s: "peta", no: Math.min(16, Math.max(1, Number(m[1]))) };
  return { s: "dash" };
}

/** pertemuan pertama yang belum PERAK (untuk tombol "lanjut") */
function nextMeeting(save: SaveData): number {
  for (let no = 1; no <= 16; no++) {
    if (meetingUnlocked(save, no) && meetingLevel(save, no) < 2) return no;
  }
  return 16;
}


/* versi lebih gelap dari warna aksen — untuk bayangan tombol */
function shade(hex: string): string {
  const h = hex.replace("#", "");
  const n = parseInt(h.length === 3 ? h.split("").map((c) => c + c).join("") : h, 16);
  const f = (v: number) => Math.max(0, Math.round(v * 0.62));
  const r = f((n >> 16) & 255);
  const gr = f((n >> 8) & 255);
  const b = f(n & 255);
  return `#${((r << 16) | (gr << 8) | b).toString(16).padStart(6, "0")}`;
}
