# Arsip Modul Cross Platform — Sistem Aplikasi Lintas Platform

> Diarsipkan: 26-10-2026 20:07 WIB (+07), dari commit `a075d08` pada branch `arena/b6418061-codeshark-qwen3-8max2`.
> Keputusan: modul **Cross Platform / CrossPlatform Studio (React Native & Expo)** disembunyikan, diarsipkan ke ZIP ini, lalu **dilepas total dari aplikasi** latihan.my.id / CodeShark Academy, termasuk seluruh materinya dan semua navigasinya.
> Catatan pekerjaan di repo: `docs/041_pengarsipan-dan-pelepasan-modul-cross-platform_26102026_2007.md`.

---

## 1. Isi arsip

Struktur folder mempertahankan path asli repository agar mudah dipasang kembali.

### Modul inti (24 file)

| Path asli | Isi |
|---|---|
| `crossplatform/index.html` | Entry HTML mandiri `/crossplatform/` |
| `src/crossplatform/main.tsx` | Entry React yang mengunci App ke arena `crossplatform` |
| `src/games/crossplatform/CrossPlatformLab.tsx` | Lab utama 16 pertemuan React Native & Expo |
| `src/games/crossplatform/CrossPlatformPhoneSimulator.tsx` | Simulator HP/Expo Go interaktif |
| `src/ui/CrossPlatformHud.tsx` | HUD/dashboard khusus MK, daftar pertemuan, dan navigasi arena |
| `src/data/crossPlatformCurriculum.ts` | Kurikulum OBE 16 pertemuan, CPMK, teori, langkah, kuis, proyek, dan asesmen |
| `src/data/materiCrossPlatform.ts` | Loader 16 dokumen Markdown dari `content/crossplatform/*.md?raw` |
| `src/lib/crossPlatformFigures.tsx` | Diagram/ilustrasi SVG materi React Native, Expo, Flexbox, navigasi, data, native API, performa, EAS, UTS/UAS |
| `content/crossplatform/*.md` (16 file) | Materi pertemuan 1–16 Sistem Aplikasi Lintas Platform |

### Snapshot titik integrasi dan navigasi (17 file)

Folder `integrasi-sebelum-dilepas/` berisi versi utuh sebelum modul dilepas:

- `src/App.tsx` — import HUD/lab, whitelist `?subgame=crossplatform`, cabang dashboard/game, label dan tab navigasi.
- `src/hub/HubApp.tsx` — kartu CrossPlatform Studio, tautan header “React Native”, dan chip hero.
- `src/data/subgames.ts` — `SubGameId`, katalog `SUBGAMES`, mode `simulator`, `SUBGAME_ORDER`, dan whitelist pilihan tersimpan.
- `src/lib/figures.tsx` — penggabungan katalog gambar web + `CROSS_PLATFORM_FIGURES` pada `getFigure()`.
- `src/ui/SubGameArtwork.tsx` — artwork HP/atom React Native untuk id `crossplatform`.
- `src/ui/icons.tsx` — definisi bersama sebelum `IconMobile` yang tidak lagi mempunyai pemakai ikut dilepas.
- `src/admin/AdminSettings.tsx` — label toggle “CrossPlatform Studio”.
- `shared/site-settings.mjs` dan `shared/site-settings.d.mts` — `GAME_IDS` lama yang masih memuat `crossplatform`.
- `src/pwa-register.ts` — pengenalan subpath `/crossplatform/` untuk service worker root.
- `index.html` dan `metadata.json` — meta/deskripsi lama yang memasarkan CrossPlatform Studio.
- `vite.config.ts` — entry build `crossplatform` dan PWA navigation fallback-nya.
- `vercel.json` dan `netlify.toml` — rewrite/redirect SPA `/crossplatform/*`.
- `scripts/test-settings-browser.mjs` — skenario entry Cross Platform nonaktif.
- `tests/site-settings.test.mjs` — ekspektasi `GAME_IDS` sebelum `crossplatform` dipensiunkan.

Total isi ZIP: **42 file** (24 modul inti + 17 snapshot + README ini).

---

## 2. Cara memasang kembali (restore)

1. Ekstrak ZIP dan kembalikan 24 file modul inti ke path aslinya, termasuk folder `crossplatform/`, `src/crossplatform/`, `src/games/crossplatform/`, dan `content/crossplatform/`.
2. Rujuk `integrasi-sebelum-dilepas/` untuk menyisipkan kembali:
   - id `"crossplatform"`, mode `"simulator"`, katalog, urutan, dan whitelist pada `src/data/subgames.ts`;
   - import/render HUD dan lab, whitelist parameter URL, label, serta tab pada `src/App.tsx`;
   - kartu hub, link header, dan chip hero pada `src/hub/HubApp.tsx`;
   - gabungan katalog gambar pada `src/lib/figures.tsx`;
   - artwork dan `IconMobile` pada file UI;
   - entry Vite, PWA fallback, subpath service worker, serta rewrite Vercel/Netlify untuk `/crossplatform/`.
3. Pengaturan situs: tambahkan kembali `'crossplatform'` ke `GAME_IDS` dan label adminnya. Sejak pelepasan ini, `migrateSettings()` membuang kunci games milik id dalam `RETIRED_GAME_IDS`, termasuk `crossplatform`. Karena itu, **hapus `crossplatform` dari `RETIRED_GAME_IDS` sebelum** menambahkannya lagi ke `GAME_IDS`. Nilai toggle lama pada dokumen yang sudah termigrasi tidak dapat dipulihkan dari dokumen itu dan harus diatur ulang lewat mekanisme settings yang berlaku.
4. Data pemain: kunci `crossplatform:<no>` pada `save.modules` tidak dihapus oleh pelepasan ini; kunci tersebut menjadi yatim selama modul tidak aktif dan berpotensi terbaca lagi setelah restore. Pilihan arena tersimpan `crossplatform` akan jatuh ke fallback selama id tersebut belum dipasang kembali.
5. Jalankan `npm run lint`, `node --test tests/*.test.mjs`, dan `npm run build` setelah restore.

Alternatif restore penuh adalah riwayat Git pada commit `a075d08` dan sebelumnya.

---

## 3. Catatan pelepasan

- ZIP disimpan di folder `arsip/` repository berdasarkan pola pengarsipan sebelumnya; folder `arsip/` bukan entry Vite/PWA sehingga tidak ikut masuk bundle aplikasi.
- Setelah pelepasan, aplikasi hanya menyajikan `tower` dan `shark`.
- String `crossplatform` yang tersisa pada runtime hanya konstanta migrasi `RETIRED_GAME_IDS` dan assertion test terkait, agar dokumen settings lama tetap dapat dibaca. Itu shim kompatibilitas data, bukan modul atau navigasi aktif.
- Kelas CSS `.phone-*` di `src/ui/ui.css` **bukan** milik modul ini; kelas tersebut dipakai pratinjau halaman Coding Tower dan sengaja dipertahankan.
