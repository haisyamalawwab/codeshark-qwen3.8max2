# Arsip MK Sistem Aplikasi Web — Backend Dasar

> Diarsipkan: 26-10-2026 19:15 WIB (+07), dari commit `4d6c28d` (merge PR #2) branch `arena/4612e910-codeshark-qwen3-8max2`.
> Keputusan: seluruh MK Sistem Aplikasi Web — Backend Dasar (**Jalur A CodeIgniter/PHP** dan **Jalur B Python Django/Flask**) disembunyikan, diarsipkan ke ZIP ini, lalu **dilepas total dari aplikasi** latihan.my.id / CodeShark Academy (registry sub-game, routing hub & App, toggle admin, artwork, meta, dan seluruh materinya).
> Catatan pekerjaan di repo: `docs/040_pengarsipan-dan-pelepasan-mk-sistem-aplikasi-web_26102026_1915.md`.

---

## 1. Isi arsip

Struktur folder di dalam ZIP mempertahankan path asli repository agar mudah dipasang kembali.

### Modul inti (40 file)

| Path asli | Isi |
|---|---|
| `src/games/backend/CiBackendLab.tsx` | Lab Jalur A — Sistem Aplikasi Web Backend Dasar (CodeIgniter 4 & MySQL) |
| `src/games/backend/CiBackendSimulator.tsx` | Simulator terminal/proyek CI4 |
| `src/games/backend/PyBackendLab.tsx` | Lab Jalur B — Python Flask/Django |
| `src/games/backend/PyBackendSimulator.tsx` | Simulator proyek Python |
| `src/data/ciBackendCurriculum.ts` | Kurikulum 16 pertemuan Jalur A + tipe bersama `BackendMeeting` + `CI_CPMK_LIST` |
| `src/data/pyBackendCurriculum.ts` | Kurikulum 16 pertemuan Jalur B + `PY_CPMK_LIST` |
| `src/data/materiBackendCi.ts` | Dokumen materi Markdown Jalur A (tersemat) + tipe `BackendMdDoc` |
| `src/data/materiBackendPy.ts` | Dokumen materi Markdown Jalur B (tersemat) |
| `content/ci_backend/*.md` (16 file) | Materi pertemuan 1–16 Jalur A (file Markdown) |
| `content/php_backend/*.md` (16 file) | **Duplikat identik** `content/ci_backend/` (terverifikasi `diff -rq` tanpa perbedaan); tidak dirujuk kode mana pun. Ikut diarsipkan apa adanya |

### Snapshot titik integrasi (11 file, folder `integrasi-sebelum-dilepas/`)

Salinan utuh file aplikasi **sebelum** modul dilepas, agar pemasangan kembali dapat meniru persis cara modul dulu terhubung:

- `src/App.tsx` — lazy import lab, whitelist `?subgame=`, cabang render dash/game, label arena terkunci, tab mode-switch.
- `src/hub/HubApp.tsx` — kartu hub `ci_backend`/`py_backend`, mesin `activeLab`/`openBackendLab`, tombol header Backend CI4/Python.
- `src/data/subgames.ts` — `SubGameId`, katalog `SUBGAMES`, `SUBGAME_ORDER`, whitelist `loadSubGame()`.
- `shared/site-settings.mjs` + `shared/site-settings.d.mts` — `GAME_IDS` lama (5 game) dan tipe `GameId`.
- `src/admin/AdminSettings.tsx` — label toggle admin "Backend PHP / CodeIgniter" & "Backend Python".
- `src/ui/CrossPlatformHud.tsx` — tombol footer "CI4 Backend" & "Python Backend".
- `src/ui/SubGameArtwork.tsx` — artwork SVG api CodeIgniter dan ular Python.
- `src/ui/icons.tsx` — definisi ikon bersama sebelum `IconServer`, `IconPhp`, dan `IconPython` yang tak lagi dipakai ikut dilepas.
- `index.html` — meta description/OG lama yang menyebut CodeIgniter 4 & Python Django/Flask.
- `scripts/test-settings-browser.mjs` — skenario smoke test `?subgame=ci_backend` nonaktif.

Total isi ZIP: **52 file** (51 file di atas + README ini).

---

## 2. Cara memasang kembali (restore)

1. Ekstrak ZIP, kembalikan folder `src/games/backend/`, 4 file `src/data/*Backend*.ts`/`*materiBackend*.ts`, dan `content/ci_backend/` (+ `content/php_backend/` bila masih ingin menyimpan duplikatnya) ke path aslinya.
2. Rujuk folder `integrasi-sebelum-dilepas/` untuk menyisipkan kembali:
   - id `"ci_backend" | "py_backend"` pada `SubGameId`, entri `SUBGAMES`, `SUBGAME_ORDER`, dan whitelist `loadSubGame()` di `src/data/subgames.ts`, termasuk mode `"backend_ci" | "backend_py"`;
   - lazy import, cabang render, tab, dan label di `src/App.tsx`;
   - kartu hub, state `activeLab`, dan tombol header di `src/hub/HubApp.tsx`;
   - artwork di `src/ui/SubGameArtwork.tsx` dan tombol footer di `src/ui/CrossPlatformHud.tsx`;
   - teks meta di `index.html`.
3. Pengaturan situs: tambahkan kembali `'ci_backend'` dan `'py_backend'` ke `GAME_IDS` (`shared/site-settings.mjs` + `.d.mts`) dan labelnya di `src/admin/AdminSettings.tsx`. Perhatian: sejak pelepasan ini, dokumen settings lama dimigrasi saat dibaca oleh `migrateSettings()` yang membuang kunci `games.ci_backend`/`games.py_backend` (`RETIRED_GAME_IDS`). Bila modul dipasang kembali, hapus kedua id itu dari `RETIRED_GAME_IDS` **sebelum** menambahkannya lagi ke `GAME_IDS`, dan ingat bahwa nilai toggle lama di dokumen settings yang sudah terlanjur termigrasi tidak dapat dikembalikan (default `true` akan dipakai karena `defaultSettings()` membangun dari `GAME_IDS`; dokumen tersimpan yang kehilangan kunci akan gagal validasi ketat sampai disimpan ulang dari admin/default).
4. Data pemain lama: kunci progres sesi seperti `ci_backend:<no>` / `py_backend:<no>` di `save.modules` (localStorage/sync) **tidak dihapus** oleh pelepasan ini; kunci tersebut menjadi yatim dan tidak mengganggu. Bila modul dipasang kembali, progres lama yang masih tersimpan di perangkat dapat terbaca lagi oleh lab (sesuai logika lab saat itu).
5. Jalankan `npm run lint`, `node --test tests/*.test.mjs`, dan `npm run build` setelah restore.

Alternatif restore penuh: seluruh modul juga tetap ada di riwayat Git pada commit `4d6c28d` dan sebelumnya.

---

## 3. Catatan pelepasan

- ZIP ini disimpan di repo pada folder `arsip/` atas keputusan pemilik repo; folder `arsip/` tidak termasuk entry Vite/PWA sehingga tidak ikut ter-bundle ke aplikasi.
- Setelah pelepasan, aplikasi hanya menyajikan 3 sub-game: `crossplatform`, `tower`, `shark`.
- String `ci_backend`/`py_backend` yang tersisa di aplikasi setelah pelepasan hanyalah konstanta migrasi `RETIRED_GAME_IDS` pada `shared/site-settings.mjs` (beserta testnya) agar dokumen settings lama tidak membuat aplikasi gagal memuat konfigurasi. Itu shim kompatibilitas data, bukan material modul.
